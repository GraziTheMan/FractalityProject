# Fractality Platform

Welcome to the Fractality Project repository.